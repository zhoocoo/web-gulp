// help 模块
'use strict';

module.exports = function() {

  console.log(' gulp sassCompile           sass编译');

  console.log(' gulp imgCompress         图片压缩');
  
  console.log(' gulp jsCompress         js压缩');
  
  console.log(' gulp jsConcat         js合并');
  
  console.log(' gulp watch          启动服务器环境，并监控相应的htmljscss的变化');

  console.log(' gulp releaseAndBackup      发布和备份');
  
  console.log(' gulp clean          清除发布和备份的文件');
  
  
};
